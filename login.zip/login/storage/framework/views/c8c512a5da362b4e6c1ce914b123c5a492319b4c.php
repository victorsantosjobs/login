<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Comentários</title>
</head>
<body>
    <center><h1>Comentários</h1></center>
   
    
    


        <?php if(auth()->guard()->check()): ?>
        
        <p>Congrats you are logged in.</p>
        <form action="/logout" method="POST">
        
            <?php echo csrf_field(); ?>
        <button>Log out</button>
        </form>    
        <?php else: ?>
       
    

   
    <div style="border: 3px solid black; text-align: center;">
    <h2>register</h2>
    <form action="/register" method="POST">
        <?php echo csrf_field(); ?>
        <input name="name" type="text" placeholder="name">
        <input name="email" type="text" placeholder="email">
        <input name="password" type="text" placeholder="password">
        <button>Register</button>
    </form> 
    <br> 
</div> 
<br>
<div style="border: 3px solid black; text-align: center;">
    <br>
    <form action="/login" method="POST">
        <?php echo csrf_field(); ?>
        <input name="loginname" type="text" placeholder="name">
        <input name="loginpassword" type="text" placeholder="password">
        <button>Login</button>
    </form> 
    <br> 
</div>
    <?php endif; ?>
 
</body>
</html><?php /**PATH C:\xampp\htdocs\lara\comentarios\resources\views/home.blade.php ENDPATH**/ ?>