<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Comentários</title>
</head>
<body>
    <center><h1>Comentários</h1></center>
   
    
    


        @auth
        
        <p>Congrats you are logged in.</p>
        <form action="/logout" method="POST">
        
            @csrf
        <button>Log out</button>
        </form>    
        @else
       
    

   
    <div style="border: 3px solid black; text-align: center;">
    <h2>register</h2>
    <form action="/register" method="POST">
        @csrf
        <input name="name" type="text" placeholder="name">
        <input name="email" type="text" placeholder="email">
        <input name="password" type="text" placeholder="password">
        <button>Register</button>
    </form> 
    <br> 
</div> 
<br>
<div style="border: 3px solid black; text-align: center;">
    <br>
    <form action="/login" method="POST">
        @csrf
        <input name="loginname" type="text" placeholder="name">
        <input name="loginpassword" type="text" placeholder="password">
        <button>Login</button>
    </form> 
    <br> 
</div>
    @endauth
 
</body>
</html>